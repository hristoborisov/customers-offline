var app = angular.module('offlineApp', ['kendo.directives']);

var el = new Everlive({
    apiKey: 'ChGozz6pHwKNAxVi',
    scheme: 'https'
});

app.run(['customerService', function (customerService) {
    customerService.init();
}]);

app.service('customerService', function () {

    this.init = function () {
        //the application DataSource

        this.dataSource = new kendo.data.DataSource({
            type: 'everlive',
            autoSync: true,
            serverFiltering: true,
            transport: {
                typeName: 'CustomersSQL',
                dataProvider: el,

            },
            schema: {
                model: {
                    id: 'Id',
                    fields: {
                        ContactName: {
                            field: 'ContactName',
                            defaultValue: ''
                        },
                        ContactTitle: {
                            fields: 'ContactTitle',
                            defaultValue: ''
                        },
                        City: {
                            field: 'City',
                            defaultValue: ''
                        }
                    },
                },
                serverSorting: true,
                serverPaging: true,
                pageSize: 50,
                autoBind: false
            }
        });

        //observable array that will be used to store products that user has selected
        this.added = new kendo.data.ObservableArray([]);
        //field that will hold reference to the last selected product (used for displaying the details)
        this.currentItem = null;
    };

    this.isOnline = function () {
        return navigator.connection.type !== 'none';
    }

    this.create = function (customer) {
        this.dataSource.add(customer);
    };

})

app.controller('homeController', ['$scope', 'customerService', function ($scope, customerService) {
    $scope.customerService = customerService;
}]);

app.controller('addController', ['$scope', 'customerService', function ($scope, customerService) {
    $scope.newCustomer = {
        ContactName: "",
        ContactTitle: "",
        CompanyName: "",
        City: ""
    }

    $scope.createNew = function (customer) {
        customerService.create(customer);
        kendo.mobile.application.navigate("#!home");
    }

}]);

function onDeviceReady() {
    StatusBar.overlaysWebView(true);
}

function onDeviceOnline() {
    alert("Online");
    el.offline(false);
    
}

function onDeviceOffline() {
    alert("Offline");
    el.offline(true);
}

document.addEventListener("deviceready", onDeviceReady, false);
document.addEventListener("online", onDeviceOnline);
document.addEventListener("offline", onDeviceOffline);