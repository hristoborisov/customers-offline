var app = angular.module('offlineApp', ['kendo.directives']);

var el = null;

app.run(['everliveService', '$rootScope', function (everliveService, $rootScope) {

    function onDeviceReady() {
        StatusBar.overlaysWebView(false);
    }

    function onDeviceOnline() {
        $rootScope.$broadcast('network:changed', "online");
        everliveService.goOnline();
    }

    function onDeviceOffline() {
        $rootScope.$broadcast('network:changed', "offline");
        everliveService.goOffline();
    }

    document.addEventListener("deviceready", onDeviceReady, false);
    document.addEventListener("online", onDeviceOnline);
    document.addEventListener("offline", onDeviceOffline);

}]);
    

app.service('customerService', ['everliveService', function (everliveService) {

    this.dataSource = everliveService.getDataSource("Customers", { autoSync: true });

    this.create = function (customer) {
        this.dataSource.add(customer);
    };

}]);

app.service('everliveService', ['$rootScope', function ($rootScope) {

    var el = new Everlive({
        apiKey: 'ChGozz6pHwKNAxVi',
        scheme: 'https',
        offlineStorage: {
            provider: {
                type: Everlive.Constants.StorageProviders.LocalStorage
            },
            syncStart: function (done) {
                $rootScope.$broadcast('sync:changed', "start");
                done();
            },
            syncEnd: function (error) {
                $rootScope.$broadcast('sync:changed', "end");
                if (error) {
                    alert(JSON.stringify(error));
                }
            }
        }
    })


    this.getDataSource = function (contentType, options) {
        return el.getKendoDataSource(contentType, options);
    }

    this.goOnline = function () {
        el.offline(false);
        el.sync();
    }

    this.goOffline = function () {
        el.offline(true);
    }

    this.isSyncing = function () {
        return el.offlineStorage.isSynchronizing();
    }

}]);


app.controller('homeController', ['$scope', 'customerService', 'everliveService', function ($scope, customerService, everliveService) {
    $scope.customerService = customerService;
    $scope.isOnline = true;
    $scope.isSyncing = false;
    $scope.showSync = false;

    $scope.$on('network:changed', function (event, data) {
        if (data == "online") {
            $scope.isOnline = true;
        } else {
            $scope.isOnline = false;
        }
        $scope.$apply();
    });

    $scope.$on('sync:changed', function (event, data) {
        $scope.isSyncing = everliveService.isSyncing();
        if ($scope.isSyncing) {
            $scope.showSync = true;
        } else {
            setTimeout(function () {
                $scope.showSync = false;
                $scope.$apply();
            }, 3000);
        }

        $scope.$apply();
    });

}]);

app.controller('addController', ['$scope', 'customerService', function ($scope, customerService) {
    $scope.newCustomer = {
        ContactName: "Hristo",
        ContactTitle: "PM",
        CompanyName: "Telerik",
        City: "Sofia"
    }

    $scope.createNew = function (customer) {
        customerService.create(customer);
        kendo.mobile.application.navigate("#!home");
    }

}]);